SSL_CERT_DIR
------------

.. versionadded:: 3.25

.. include:: ENV_VAR.txt

Specify default directory containing CA certificates.  It overrides
the default CA directory used.
